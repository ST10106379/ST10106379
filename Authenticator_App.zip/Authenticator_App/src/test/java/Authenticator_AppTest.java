import com.mycompany.authenticator_app.Authenticator_App;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class Authenticator_AppTest {
    @Test
    public void testCheckUserName_Valid() {
        String username = "kyl_1";
        assertTrue(Authenticator_App.checkUserName(username));
    }

    @Test
    public void testCheckUserName_Invalid() {
        String username = "username";
        assertFalse(Authenticator_App.checkUserName(username));
    }

    @Test
    public void testCheckPassword_Valid() {
        String password = "Ch&&sec@ke99!";
        assertTrue(Authenticator_App.checkPassword(password));
    }

    @Test
    public void testCheckPassword_Invalid() {
        String password = "password";
        assertFalse(Authenticator_App.checkPassword(password));
    }
   
    @Test
    public void testCellPhoneIncorrectlyFormatted() {
    String phoneNumber = "08966553";
    assertFalse(Authenticator_App.checkPhoneNumber(phoneNumber));
}
}