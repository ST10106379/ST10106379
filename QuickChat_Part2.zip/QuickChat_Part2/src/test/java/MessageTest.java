import com.mycompany.quickchat.Message;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Message class - Part 2.
 * Covers all assertions specified in section 9 of the Part 2 brief.
 */
public class MessageTest {

    @BeforeAll
    static void disableFileIO() {
        // Stop tests from writing to stored_messages.json
        Message.disableFileStorageForTests();
    }

    @BeforeEach
    void setUp() {
        Message.reset();
    }

    // ---------- Test Case 1: Message length (≤ 250 chars) ----------

    @Test
    public void messageLength_success_returnsReadyToSend() {
        String body = "Hi Mike, can you join us for dinner tonight?";
        assertEquals("Message ready to send.", Message.validateMessageLength(body));
    }

    @Test
    public void messageLength_failure_returnsExceedsMessage() {
        StringBuilder over = new StringBuilder();
        for (int i = 0; i < 260; i++) over.append("a"); // 260 chars => 10 over
        String result = Message.validateMessageLength(over.toString());
        assertTrue(result.startsWith("Message exceeds 250 characters by 10"),
                "Expected the failure message to mention 10 chars over, got: " + result);
    }

    // ---------- Test Case 2: Recipient cell formatting ----------

    @Test
    public void recipientCell_success_validInternationalNumber() {
        Message m = new Message("+27718693002", "test", "0000000000", 0);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    public void recipientCell_failure_missingInternationalCode() {
        Message m = new Message("08575975889", "test", "0000000000", 0);
        assertNotEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    // ---------- Test Case 3: Message hash is correct ----------

    @Test
    public void messageHash_returnsExpectedFormat() {
        // Brief specifies: with Test Case 1 data, hash should be "00:0:HITONIGHT"
        // when the message ID starts with "00" and the message number is 0.
        Message m = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?",
                "0000000000",   // controlled ID so test is deterministic
                0
        );
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    // ---------- Test Case 4: Message ID is created ----------

    @Test
    public void messageID_isGeneratedAndValid() {
        Message m = new Message("+27718693002", "Hello there");
        assertNotNull(m.getMessageID());
        assertEquals(10, m.getMessageID().length(), "Message ID should be 10 digits");
        assertTrue(m.checkMessageID());
    }

    // ---------- Test Case 5: MessageSent options ----------

    @Test
    public void sentMessage_sendOption_returnsSuccessfullySent() {
        Message m = new Message("+27718693002", "Hi Mike", "0000000000", 0);
        assertEquals("Message successfully sent.", m.sentMessage(1));
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void sentMessage_disregardOption_returnsPressZero() {
        Message m = new Message("+27718693002", "Hi Keegan", "0000000000", 0);
        assertEquals("Press 0 to delete the message.", m.sentMessage(2));
        assertEquals(0, Message.returnTotalMessages(), "Disregarded msgs shouldn't count");
    }

    @Test
    public void sentMessage_storeOption_returnsSuccessfullyStored() {
        Message m = new Message("+27718693002", "Hi Later", "0000000000", 0);
        assertEquals("Message successfully stored.", m.sentMessage(3));
    }

    // ---------- Bonus: matches the assignment test data exactly ----------

    @Test
    public void assignmentTestData_message1_sendsSuccessfully() {
        Message m1 = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Cell phone number successfully captured.", m1.checkRecipientCell());
        assertEquals("Message ready to send.", Message.validateMessageLength(m1.getMessageBody()));
        assertEquals("Message successfully sent.", m1.sentMessage(1));
    }

    @Test
    public void assignmentTestData_message2_disregardedSuccessfully() {
        Message m2 = new Message("08575975889",
                "Hi Keegan, did you receive the payment?");
        // Recipient should fail validation (no +)
        assertNotEquals("Cell phone number successfully captured.", m2.checkRecipientCell());
        assertEquals("Press 0 to delete the message.", m2.sentMessage(2));
    }
}
