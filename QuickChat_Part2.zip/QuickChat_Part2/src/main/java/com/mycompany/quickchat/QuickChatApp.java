package com.mycompany.quickchat;

import java.util.Scanner;

/**
 * QuickChat - standalone Part 2 application.
 *
 * Includes a minimal placeholder login so the brief's requirement
 * ("Users should only be able to send messages if they have logged in
 * successfully") is satisfied without needing the full Part 1 registration
 * system. Any non-empty username and password will be accepted.
 */
public class QuickChatApp {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        if (!performLogin()) {
            System.out.println("Login failed. Exiting QuickChat.");
            return;
        }

        // Welcome message (requirement #2)
        System.out.println("Welcome to QuickChat.");

        // Menu loop (requirements #3 and #4)
        boolean running = true;
        while (running) {
            int choice = showMenu();
            switch (choice) {
                case 1:
                    sendMessagesFlow();
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }

        // Total accumulated messages on exit (requirement #6)
        System.out.println("\nTotal messages sent this session: " + Message.returnTotalMessages());
        System.out.println("Goodbye!");
    }

    private static boolean performLogin() {
        System.out.println("=== QuickChat Login ===");
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine().trim();
        if (username.isEmpty() || password.isEmpty()) {
            System.out.println("Username and password are required.");
            return false;
        }
        System.out.println("Login successful!\n");
        return true;
    }

    private static int showMenu() {
        System.out.println("\n--- QuickChat Menu ---");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
        System.out.print("Enter choice: ");
        return parseIntOrDefault(scanner.nextLine().trim(), -1);
    }

    /** Requirements #5 and #7 - ask how many, loop, validate, build, ask action, display details. */
    private static void sendMessagesFlow() {
        System.out.print("How many messages do you want to send? ");
        int numMessages = parseIntOrDefault(scanner.nextLine().trim(), -1);
        if (numMessages <= 0) {
            System.out.println("Please enter a positive number.");
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + numMessages + " ---");

            // Recipient (with international code)
            String recipient;
            while (true) {
                System.out.print("Recipient cell number (e.g. +27718693002): ");
                recipient = scanner.nextLine().trim();
                String result = Message.checkRecipientCell(recipient);
                System.out.println(result);
                if (result.equals("Cell phone number successfully captured.")) break;
            }

            // Message body (max 250 chars)
            String body;
            while (true) {
                System.out.print("Enter your message (max 250 characters): ");
                body = scanner.nextLine();
                String validate = Message.validateMessageLength(body);
                System.out.println(validate);
                if (validate.equals("Message ready to send.")) break;
            }

            // Build the message (auto-generates ID, number and hash)
            Message msg = new Message(recipient, body);

            // Ask what to do with it
            System.out.println("\nWhat would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Choice: ");
            int action = parseIntOrDefault(scanner.nextLine().trim(), -1);

            System.out.println(msg.sentMessage(action));

            // Display full details after sending (requirement #7)
            if (action == 1) {
                System.out.println("\n--- Message Details ---");
                System.out.println("Message ID:   " + msg.getMessageID());
                System.out.println("Message Hash: " + msg.getMessageHash());
                System.out.println("Recipient:    " + msg.getRecipient());
                System.out.println("Message:      " + msg.getMessageBody());
            }
        }

        System.out.println("\nMessages sent so far: " + Message.returnTotalMessages());
    }

    private static int parseIntOrDefault(String s, int fallback) {
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) { return fallback; }
    }
}
