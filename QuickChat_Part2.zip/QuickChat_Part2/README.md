# QuickChat — Part 2 (Standalone)

Standalone Maven project for **Part 2: Sending Messages** of the
PROG5121 POE assignment.

This project contains only what Part 2 requires — no Part 1 registration
system and no Part 3 reports / arrays. A minimal placeholder login is
included to satisfy the brief's requirement that users must be logged in
before sending messages.

## Run

```bash
mvn compile exec:java
```

Log in with any non-empty username and password, then use the menu:

1. **Send Messages** — enter how many, then for each: recipient, body,
   and choose Send / Disregard / Store.
2. **Show recently sent messages** — displays "Coming Soon." as per brief.
3. **Quit** — exits with a session total.

## Test

```bash
mvn test
```

All 11 unit tests should pass (the 9 from section 9 of the brief plus
2 bonus tests using the exact assignment test data).

## Project structure

```
QuickChat_Part2/
├── pom.xml
└── src/
    ├── main/java/com/mycompany/quickchat/
    │   ├── Message.java       # Message class with all Part 2 methods
    │   └── QuickChatApp.java  # Entry point: login + menu loop
    └── test/java/
        └── MessageTest.java   # Part 2 unit tests
```
